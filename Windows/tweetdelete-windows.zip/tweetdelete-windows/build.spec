# PyInstaller build spec for TweetDelete.
#
# Run from the project root (the folder containing this file) with:
#   pyinstaller build.spec
#
# Produces a one-folder build at dist/TweetDelete/ containing TweetDelete.exe
# plus its bundled files. One-folder (rather than --onefile) is deliberate:
# onefile self-extracts to a temp directory on every launch, which is both
# slower to start and more likely to trip antivirus heuristics that flag
# self-extracting executables. The Inno Setup installer (installer.iss)
# packages this whole folder behind a single Start Menu / desktop shortcut,
# so end users never see the individual files either way.

# -*- mode: python ; coding: utf-8 -*-

a = Analysis(
    ['tray_app.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('public', 'public'),
        ('packaging/icon.ico', '.'),
    ],
    hiddenimports=[
        # pystray picks its backend dynamically per-OS at import time, which
        # PyInstaller's static analysis can miss - list the Windows one
        # explicitly so it's always bundled regardless of what OS this spec
        # happens to be processed on.
        'pystray._win32',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='TweetDelete',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,  # no terminal window - this is the tray app, not a CLI tool
    icon='packaging/icon.ico',
    disable_windowed_traceback=False,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='TweetDelete',
)
