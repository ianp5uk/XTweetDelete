#!/usr/bin/env python3
"""
TweetDelete local helper server.

Why this exists: X's API does not send Access-Control-Allow-Origin headers,
so a browser calling api.x.com directly from JavaScript is blocked by CORS
(this has been an open X API limitation since 2016 - see
https://devcommunity.x.com/t/twitter-api-v2-public-client-no-access-control-allow-origin-header-present-cors/170402).

This script does three things:
  1. Serves the static files in ./public (the actual app: HTML/CSS/JS).
  2. Proxies any request under /api/x/<path> to https://api.x.com/<path>,
     forwarding method, headers, and body verbatim, and returns the response
     to the browser as same-origin (no CORS problem, because the browser is
     now only ever talking to 127.0.0.1).
  3. (v1.0.4+) Hosts the background deletion runner (runner.py) under
     /__runner/..., so the delete loop and its rate-limit waits keep going
     when the browser tab is hidden, throttled or closed. The page still
     does login, fetching, filtering, the archive step and confirmation,
     then hands over the final list - same split as the Android app.

Usage as a standalone script:
    python3 server.py [port]

Usage as a module (used by the Windows tray app build - see packaging/):
    from server import build_server
    httpd = build_server(port=8765)
    httpd.serve_forever()   # call httpd.shutdown() from another thread to stop
"""
import http.server
import json
import os
import sys
import urllib.request
import urllib.error

from runner import DeletionRunner

DEFAULT_PORT = int(os.environ.get("PORT", "8765"))
# TWEETDELETE_API_BASE exists only for testing against a mock X API.
UPSTREAM = os.environ.get("TWEETDELETE_API_BASE", "https://api.x.com").rstrip("/")
RUNNER_PREFIX = "/__runner/"

# One runner per helper process, created by build_server().
RUNNER = None

# Headers that must not be forwarded as-is between hop-by-hop boundaries.
HOP_BY_HOP = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailers", "transfer-encoding", "upgrade", "host", "content-length",
}


def resource_dir():
    """Directory containing this script's own files. Handles both a normal
    checkout and a PyInstaller-frozen executable, where bundled data files
    are unpacked to a temp folder referenced by sys._MEIPASS at runtime.
    See https://pyinstaller.org/en/stable/runtime-information.html
    """
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return sys._MEIPASS
    return os.path.dirname(os.path.abspath(__file__))


PUBLIC_DIR = os.path.join(resource_dir(), "public")


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=PUBLIC_DIR, **kwargs)

    # Silence default noisy logging format, keep it short.
    def log_message(self, fmt, *args):
        sys.stderr.write("[server] " + (fmt % args) + "\n")

    def do_OPTIONS(self):
        self.send_response(204)
        # Never advertise CORS for the runner: it holds the OAuth tokens
        # during a run, so only the app's own page may talk to it.
        if not self.path.startswith(RUNNER_PREFIX):
            self._send_cors_headers()
        self.end_headers()

    def do_GET(self):
        if self.path.startswith(RUNNER_PREFIX):
            self._runner("GET")
        elif self.path.startswith("/api/x/"):
            self._proxy("GET")
        elif self.path == "/__tweetdelete_health":
            payload = b'{"app":"tweetdelete"}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
        elif self.path == "/api/help":
            self._serve_help_pdf()
        else:
            super().do_GET()

    def do_POST(self):
        if self.path.startswith(RUNNER_PREFIX):
            self._runner("POST")
        elif self.path.startswith("/api/x/"):
            self._proxy("POST")
        else:
            self.send_error(404)

    def do_DELETE(self):
        if self.path.startswith("/api/x/"):
            self._proxy("DELETE")
        else:
            self.send_error(404)

    def do_PUT(self):
        if self.path.startswith("/api/x/"):
            self._proxy("PUT")
        else:
            self.send_error(404)

    # ---- Background runner endpoints ----

    def _runner_request_allowed(self):
        """Same-origin only. The Host check defeats DNS-rebinding (a remote
        site resolving its own name to 127.0.0.1); the custom header can't be
        sent cross-origin without a CORS preflight, which these paths never
        approve. Together they stop any other web page reading the tokens or
        starting/cancelling a run."""
        host = (self.headers.get("Host") or "").split(":")[0].lower()
        if host not in ("127.0.0.1", "localhost"):
            return False
        return self.headers.get("X-TweetDelete") == "1"

    def _json(self, status, obj):
        payload = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def _runner(self, method):
        if not self._runner_request_allowed():
            self._json(403, {"error": "forbidden"})
            return
        from urllib.parse import urlsplit, parse_qs
        parts = urlsplit(self.path)
        action = parts.path[len(RUNNER_PREFIX):]
        query = parse_qs(parts.query)
        body = {}
        if method == "POST":
            length = int(self.headers.get("Content-Length", 0) or 0)
            raw = self.rfile.read(length) if length else b""
            try:
                body = json.loads(raw.decode("utf-8")) if raw else {}
            except ValueError:
                self._json(400, {"error": "invalid JSON"})
                return
        r = RUNNER
        if method == "GET" and action == "status":
            self._json(200, r.status())
        elif method == "GET" and action == "results":
            start = int((query.get("from") or ["0"])[0] or 0)
            self._json(200, r.results_from(start))
        elif method == "POST" and action == "tokens":
            # POST, not GET, so it can never be a cacheable/simple cross-site read.
            self._json(200, {"tokens": r.take_updated_tokens()})
        elif method == "POST" and action == "start":
            err = r.start(body)
            self._json(200 if not err else 409, {"error": err})
        elif method == "POST" and action == "pause":
            r.set_paused(bool(body.get("paused")))
            self._json(200, {"ok": True})
        elif method == "POST" and action == "cancel":
            r.cancel()
            self._json(200, {"ok": True})
        elif method == "POST" and action == "clear":
            r.clear()
            self._json(200, {"ok": True})
        else:
            self._json(404, {"error": "unknown runner action"})

    def _send_cors_headers(self):
        # Not strictly required since the browser only ever calls same-origin
        # 127.0.0.1, but harmless to include and helps if this is ever opened
        # from a different local port during development.
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")

    def _serve_help_pdf(self):
        # The same public/ folder ships in both the Windows and Linux
        # builds, but each platform's help guide has a different filename
        # (and different content - install/uninstall steps differ). Rather
        # than hardcoding one filename into the HTML, redirect to whichever
        # one is actually present in this build, so the same footer link
        # works correctly regardless of which package built it.
        candidates = [
            "TweetDelete for Windows.pdf",
            "TweetDelete for Linux.pdf",
            "TweetDelete for Debian.pdf",
            "TweetDelete for Ubuntu.pdf",
        ]
        for name in candidates:
            if os.path.exists(os.path.join(PUBLIC_DIR, name)):
                from urllib.parse import quote
                self.send_response(302)
                self.send_header("Location", "/" + quote(name))
                self.end_headers()
                return
        self.send_error(404, "No help guide has been added to this build yet.")

    def _proxy(self, method):
        upstream_path = self.path[len("/api/x") :]  # keep leading slash
        url = UPSTREAM + upstream_path

        length = int(self.headers.get("Content-Length", 0) or 0)
        body = self.rfile.read(length) if length else None

        fwd_headers = {}
        for key, value in self.headers.items():
            if key.lower() not in HOP_BY_HOP and key.lower() != "content-length":
                fwd_headers[key] = value

        req = urllib.request.Request(url, data=body, headers=fwd_headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                self._relay(resp.status, resp.headers, resp.read())
        except urllib.error.HTTPError as e:
            self._relay(e.code, e.headers, e.read())
        except Exception as e:
            payload = ('{"error":"proxy_failed","detail":%r}' % str(e)).encode("utf-8")
            self.send_response(502)
            self._send_cors_headers()
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

    def _relay(self, status, headers, body):
        self.send_response(status)
        self._send_cors_headers()
        for key, value in headers.items():
            if key.lower() not in HOP_BY_HOP:
                self.send_header(key, value)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def is_port_free(port, host="127.0.0.1"):
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.3)
        return s.connect_ex((host, port)) != 0


def find_free_port(preferred=DEFAULT_PORT, attempts=20):
    """Returns `preferred` if free, otherwise the next free port after it.
    Used by the tray app so a second launch (or a port already taken by
    something else) doesn't just crash silently.
    """
    port = preferred
    for _ in range(attempts):
        if is_port_free(port):
            return port
        port += 1
    raise RuntimeError(f"No free port found near {preferred}")


def find_running_instance(preferred=DEFAULT_PORT, attempts=20):
    """Checks whether a TweetDelete server is already listening nearby (e.g.
    from a previous launch that's still running). Returns the port it's on,
    or None. Used by the tray app to avoid starting a second server and
    instead just re-open the browser to the existing one.
    """
    import urllib.request

    port = preferred
    for _ in range(attempts):
        if not is_port_free(port):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/__tweetdelete_health", timeout=0.5) as resp:
                    if resp.status == 200 and b"tweetdelete" in resp.read():
                        return port
            except Exception:
                pass  # Something else is using this port — not us, keep looking.
        port += 1
    return None


def get_runner(log=None):
    """The process-wide runner; created and restored (resuming any run that
    was interrupted by a restart) on first use."""
    global RUNNER
    if RUNNER is None:
        state_dir = os.environ.get("TWEETDELETE_STATE_DIR") or None
        RUNNER = DeletionRunner(state_dir=state_dir, api_base=UPSTREAM, log=log)
        RUNNER.restore()
    return RUNNER


def build_server(port=None, log=None):
    """Creates (but does not start) the HTTP server. Call .serve_forever()
    to run it, and .shutdown() from another thread to stop it cleanly.
    """
    os.makedirs(PUBLIC_DIR, exist_ok=True)
    chosen_port = port if port is not None else find_free_port(DEFAULT_PORT)
    server = http.server.ThreadingHTTPServer(("127.0.0.1", chosen_port), Handler)
    get_runner(log)
    return server


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else None
    server = build_server(port)
    actual_port = server.server_address[1]
    print(f"TweetDelete running at http://127.0.0.1:{actual_port}/")
    print(f"OAuth callback / redirect URI to register in your X app: http://127.0.0.1:{actual_port}/callback.html")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
